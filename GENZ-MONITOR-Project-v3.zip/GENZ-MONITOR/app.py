import streamlit as st
import pandas as pd
from modules.database import init_db, save_ip_search, get_ip_history, clear_ip_history, save_camera_check, get_camera_history
from modules.ip_intelligence import lookup_public_ip
from modules.network import ping_host, check_tcp_port, get_local_network_stats
from modules.camera import check_camera_ports, build_rtsp_url, read_rtsp_frame
from modules.audio import list_input_devices, record_test
from modules.wazuh import get_manager_token, get_agents, get_alerts
from modules.website_analytics import summarize_dns_csv

st.set_page_config(page_title="GENZ MONITOR", page_icon="🛡️", layout="wide")
init_db()

st.markdown("""
<style>
.block-container {padding-top: 1.5rem;}
[data-testid="stAppViewContainer"] {background: #0b1020;}
[data-testid="stSidebar"] {background: #111a2e;}
h1,h2,h3 {color: #e8f0ff;}
</style>
""", unsafe_allow_html=True)

st.title("🛡️ GENZ MONITOR")
st.caption("Network Intelligence • Device Health • Authorized CCTV Checks")
st.sidebar.title("GENZ CONTROL")
page = st.sidebar.radio("Navigation", [
    "Dashboard", "IP Intelligence", "Network Monitoring",
    "Website Analytics", "Camera Studio", "CCTV Monitoring", "Audio Management",
    "Security Center", "Reports"
])

if page == "Dashboard":
    st.subheader("Monitoring overview")
    a,b,c = st.columns(3)
    a.metric("Modules", "7 + integrations")
    b.metric("IP search records", len(get_ip_history()))
    c.metric("Camera checks", len(get_camera_history()))
    st.info("Start with IP Intelligence or Network Monitoring. Use only devices and networks you own or are authorized to administer.")
    st.markdown("### Project modules")
    st.write("IP Intelligence • Network Monitoring • Website Analytics • CCTV Monitoring • Audio Management • Security Center • Reports")

elif page == "IP Intelligence":
    st.subheader("🌍 IP Intelligence")
    st.write("Look up public IP allocation and approximate geolocation. Private/local IPs are intentionally not sent to an external lookup service.")
    ip = st.text_input("Public IPv4 / IPv6 address", placeholder="Example: 1.1.1.1")
    if st.button("Search IP", type="primary"):
        result = lookup_public_ip(ip)
        if result.get("error"):
            st.error(result["error"])
        else:
            save_ip_search(result)
            cols = st.columns(3)
            cols[0].metric("Country", result.get("country") or "Unknown")
            cols[1].metric("City / Region", f'{result.get("city") or "Unknown"} / {result.get("region") or "Unknown"}')
            cols[2].metric("ASN", result.get("asn") or "Unknown")
            st.json(result)
            lat, lon = result.get("latitude"), result.get("longitude")
            if lat is not None and lon is not None:
                st.caption("Approximate network geolocation only—not a person's exact location.")
                st.map(pd.DataFrame({"lat":[lat], "lon":[lon]}))
    st.markdown("### Search history")
    hist = get_ip_history()
    if hist:
        df = pd.DataFrame(hist, columns=["ID","IP","Country","City","ISP","ASN","Searched At"])
        st.dataframe(df, use_container_width=True)
        st.download_button("Export IP history CSV", df.to_csv(index=False), "genz_ip_history.csv", "text/csv")
        if st.button("Clear IP search history"):
            clear_ip_history()
            st.rerun()
    else:
        st.info("No IP searches saved yet.")

elif page == "Network Monitoring":
    st.subheader("🖧 Network Monitoring")
    st.caption("Run checks only against systems you own or have explicit permission to monitor.")
    host = st.text_input("Host / IP to check", "127.0.0.1")
    col1,col2 = st.columns(2)
    with col1:
        if st.button("Ping host"):
            result = ping_host(host)
            st.json(result)
    with col2:
        port = st.number_input("TCP port", min_value=1, max_value=65535, value=443)
        if st.button("Check TCP port"):
            st.json(check_tcp_port(host, int(port)))
    st.markdown("### Local machine network usage")
    stats = get_local_network_stats()
    st.json(stats)

elif page == "Website Analytics":
    st.subheader("🌐 Website Analytics")
    st.warning("For privacy and HTTPS accuracy, this module analyzes DNS/proxy/firewall CSV logs you are authorized to access. It does not secretly inspect browsing or decrypt HTTPS.")
    st.markdown("Expected CSV columns: `timestamp`, `client_ip`, `domain`, `bytes_sent`, `bytes_received`.")
    upload = st.file_uploader("Upload authorized DNS / proxy usage CSV", type=["csv"])
    if upload:
        try:
            df = pd.read_csv(upload)
            summary = summarize_dns_csv(df)
            if isinstance(summary, str):
                st.error(summary)
            else:
                st.dataframe(summary, use_container_width=True)
                st.download_button("Download domain usage report", summary.to_csv(index=False), "website_usage.csv", "text/csv")
        except Exception as e:
            st.error(f"Could not process CSV: {e}")

elif page == "Camera Studio":
    st.subheader("📷 Laptop • USB • Mobile Camera Studio")
    st.markdown("""
    This studio uses the **browser camera** on the device opening GENZ MONITOR:
    - Laptop built-in webcam
    - USB webcam connected to the laptop
    - Mobile phone front or rear camera when this dashboard is opened in the phone browser

    The browser will ask for camera permission. Choose the actual camera in the browser/device permission prompt when multiple cameras are connected.
    """)
    st.warning("Camera starts only when you click Start camera and grant browser permission. Stop the stream when finished. Video is displayed live and is not saved by this module.")
    try:
        from streamlit_webrtc import webrtc_streamer, WebRtcMode
        facing = st.radio("Mobile camera preference", ["Front camera", "Rear camera"], horizontal=True,
                          help="On phones, rear camera is usually better for monitoring. On laptops, use the browser's camera chooser if available.")
        facing_mode = "user" if facing == "Front camera" else "environment"
        st.caption("For laptop/USB webcams, select the desired device in the browser camera chooser. For mobile, use the rear/front preference above.")
        webrtc_streamer(
            key="genz-browser-camera",
            mode=WebRtcMode.SENDRECV,
            video_frame_callback=lambda frame: frame,
            media_stream_constraints={"video": {"facingMode": facing_mode}, "audio": False},
            async_processing=True,
        )
        st.caption("If the browser does not show video, check camera permission, close other apps using the camera, and use HTTPS (or localhost).")
    except ImportError:
        st.error("Browser camera component is not installed. Run: pip install streamlit-webrtc")
    except Exception as exc:
        st.error(f"Browser camera could not start: {exc}")
    st.markdown("### Supported camera sources")
    st.dataframe(pd.DataFrame([
        {"Source": "Laptop built-in webcam", "Connection": "Browser camera permission", "Status": "Supported"},
        {"Source": "USB webcam", "Connection": "Connect to the computer running the browser; select in browser chooser", "Status": "Supported"},
        {"Source": "Mobile front/rear camera", "Connection": "Open dashboard in phone browser; HTTPS required on LAN", "Status": "Supported"},
        {"Source": "IP CCTV", "Connection": "RTSP stream in CCTV Monitoring", "Status": "Supported separately"},
    ]), hide_index=True, use_container_width=True)

elif page == "CCTV Monitoring":
    st.subheader("📹 CCTV / IP Camera Monitoring")
    st.warning("Connect only to a camera you own or are explicitly authorized to administer. Live view uses the camera's documented RTSP stream; credentials are held only in this Streamlit session and are not written to the database.")
    with st.expander("Camera service health", expanded=True):
        cam_ip = st.text_input("Camera IP / hostname", "192.168.1.100", key="cam_health_ip")
        if st.button("Check camera services", type="primary"):
            result = check_camera_ports(cam_ip)
            save_camera_check(result)
            st.json(result)
    st.markdown("### Authorized RTSP live view")
    with st.form("rtsp_form"):
        rtsp_host = st.text_input("Camera host / IP", "192.168.1.100")
        rtsp_port = st.number_input("RTSP port", min_value=1, max_value=65535, value=554)
        rtsp_path = st.text_input("RTSP path", "/stream1", help="Enter the stream path from the camera vendor's documentation; do not guess endpoints.")
        rtsp_user = st.text_input("Camera username")
        rtsp_pass = st.text_input("Camera password", type="password")
        start_stream = st.form_submit_button("Start live view")
    if start_stream:
        st.session_state["rtsp_config"] = {"host": rtsp_host.strip(), "port": int(rtsp_port), "path": rtsp_path,
                                            "username": rtsp_user, "password": rtsp_pass}
        st.session_state["rtsp_active"] = True
    if st.session_state.get("rtsp_active") and st.session_state.get("rtsp_config"):
        if st.button("Stop live view"):
            st.session_state["rtsp_active"] = False
            st.session_state.pop("rtsp_config", None)
            st.rerun()
        cfg = st.session_state["rtsp_config"]
        @st.fragment(run_every=1.0)
        def live_camera_panel():
            url = build_rtsp_url(cfg["host"], cfg["path"], cfg["username"], cfg["password"], cfg["port"])
            frame, error = read_rtsp_frame(url)
            if error:
                st.error(error)
            else:
                st.image(frame, caption=f"Authorized camera: {cfg['host']} • refreshing about once per second", use_container_width=True)
        live_camera_panel()
    else:
        st.caption("Enter the exact RTSP path and click Start live view. The preview refreshes approximately once per second while this page is open.")
    st.markdown("### Camera check history")
    history = get_camera_history()
    if history:
        st.dataframe(pd.DataFrame(history, columns=["ID","Camera IP","Results JSON","Checked At"]), use_container_width=True)

elif page == "Audio Management":
    st.subheader("🎙️ Local Microphone Test")
    st.warning("The microphone is accessed only after you select a device and press Record 3-second test. Audio stays in memory for this session, is not uploaded or saved to disk, and is not remotely accessible.")
    try:
        devices = list_input_devices()
        if not devices:
            st.error("No microphone input device detected. Check OS privacy permissions and microphone connection.")
        else:
            labels = {f"{d['id']} — {d['name']} ({d['channels']} input channels)": d for d in devices}
            selected = st.selectbox("Choose microphone", list(labels.keys()))
            if st.button("Record 3-second microphone test", type="primary"):
                with st.spinner("Recording locally for 3 seconds…"):
                    wav_bytes, levels = record_test(labels[selected]["id"])
                st.success("Microphone test complete. Audio was kept in memory only.")
                st.json(levels)
                st.audio(wav_bytes, format="audio/wav")
                if levels["rms_level"] < 0.002:
                    st.warning("Very low input level. Check microphone mute, input gain and OS permissions.")
                else:
                    st.success("Microphone input detected. Listen to the playback to confirm quality.")
    except Exception as exc:
        st.error(f"Audio device error: {exc}")
        st.caption("On Linux, PortAudio/system audio packages may be required. On Windows, check microphone privacy permissions.")

elif page == "Security Center":
    st.subheader("🚨 Security Center — Wazuh SIEM")
    st.caption("Read-only integration: fetches agent inventory from Wazuh Manager API and recent alerts from Wazuh Indexer. No rules, agents, or configurations are modified.")
    with st.form("wazuh_form"):
        manager_url = st.text_input("Wazuh Manager API URL", "https://127.0.0.1:55000")
        manager_user = st.text_input("Wazuh API username", value="")
        manager_pass = st.text_input("Wazuh API password", type="password")
        indexer_url = st.text_input("Wazuh Indexer URL", "https://127.0.0.1:9200")
        indexer_user = st.text_input("Wazuh Indexer username", value="")
        indexer_pass = st.text_input("Wazuh Indexer password", type="password")
        alert_limit = st.number_input("Recent alerts to load", min_value=1, max_value=100, value=25)
        verify_tls = st.checkbox("Verify TLS certificates (recommended)", value=True)
        connect_wazuh = st.form_submit_button("Connect to Wazuh (read-only)", type="primary")
    if connect_wazuh:
        try:
            with st.spinner("Authenticating to Wazuh Manager…"):
                token = get_manager_token(manager_url, manager_user, manager_pass, verify_tls)
                agents, agent_total = get_agents(manager_url, token, verify_tls)
            st.success(f"Manager API connected. Agent records returned: {len(agents)} / {agent_total}")
            if agents:
                st.dataframe(pd.json_normalize(agents), use_container_width=True)
            with st.spinner("Querying Wazuh Indexer alerts…"):
                alerts = get_alerts(indexer_url, indexer_user, indexer_pass, int(alert_limit), verify_tls)
            st.success(f"Indexer connected. Recent alert records: {len(alerts)}")
            if alerts:
                alert_df = pd.json_normalize(alerts)
                st.dataframe(alert_df, use_container_width=True)
                st.download_button("Export Wazuh alerts CSV", alert_df.to_csv(index=False), "wazuh_alerts.csv", "text/csv")
            else:
                st.info("No alert documents were returned by the selected Wazuh alert index.")
        except Exception as exc:
            st.error(f"Wazuh connection failed: {exc}")
            st.info("Check API/indexer URLs, credentials, network access, TLS trust, and that the Wazuh alert indices exist.")
    st.markdown("### Other telemetry sources")
    st.write("DNS/proxy CSV analytics are available under Website Analytics. Zeek conn.log and dns.log ingestion can be added as another read-only data source.")
    st.warning("An alert is an investigation lead, not proof of compromise. Use least-privilege read-only Wazuh accounts and trusted TLS certificates.")

elif page == "Reports":
    st.subheader("📊 Reports")
    ip_hist = get_ip_history()
    cam_hist = get_camera_history()
    st.metric("Saved IP lookups", len(ip_hist))
    st.metric("Saved camera health checks", len(cam_hist))
    if ip_hist:
        ip_df = pd.DataFrame(ip_hist, columns=["ID","IP","Country","City","ISP","ASN","Searched At"])
        st.download_button("Download IP report", ip_df.to_csv(index=False), "ip_report.csv", "text/csv")
    if cam_hist:
        cam_df = pd.DataFrame(cam_hist, columns=["ID","Camera IP","Results JSON","Checked At"])
        st.download_button("Download camera report", cam_df.to_csv(index=False), "camera_report.csv", "text/csv")

st.divider()
st.caption("GENZ MONITOR • Portfolio Lab Build • Store credentials securely • Respect privacy and authorization")
