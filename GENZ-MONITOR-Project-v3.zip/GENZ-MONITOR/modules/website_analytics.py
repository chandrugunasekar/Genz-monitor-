import pandas as pd

REQUIRED = {"domain", "bytes_sent", "bytes_received"}

def summarize_dns_csv(df: pd.DataFrame):
    missing = REQUIRED - set(df.columns)
    if missing:
        return "Missing required CSV columns: " + ", ".join(sorted(missing))
    work = df.copy()
    work["bytes_sent"] = pd.to_numeric(work["bytes_sent"], errors="coerce").fillna(0)
    work["bytes_received"] = pd.to_numeric(work["bytes_received"], errors="coerce").fillna(0)
    work["total_bytes"] = work["bytes_sent"] + work["bytes_received"]
    group_cols = ["domain"]
    if "client_ip" in work.columns:
        group_cols = ["client_ip", "domain"]
    summary = work.groupby(group_cols, dropna=False)[
        ["bytes_sent", "bytes_received", "total_bytes"]
    ].sum().reset_index()
    summary = summary.sort_values("total_bytes", ascending=False)
    for col in ["bytes_sent", "bytes_received", "total_bytes"]:
        summary[col + "_MB"] = (summary[col] / (1024 * 1024)).round(2)
    return summary
