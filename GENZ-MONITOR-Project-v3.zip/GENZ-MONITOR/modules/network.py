import platform
import subprocess
import socket
import psutil

def ping_host(host: str) -> dict:
    flag = "-n" if platform.system().lower() == "windows" else "-c"
    try:
        result = subprocess.run(
            ["ping", flag, "1", host],
            capture_output=True, text=True, timeout=5
        )
        return {"host": host, "reachable": result.returncode == 0,
                "output": (result.stdout or result.stderr)[-1200:]}
    except Exception as exc:
        return {"host": host, "error": str(exc)}

def check_tcp_port(host: str, port: int) -> dict:
    try:
        with socket.create_connection((host, port), timeout=3):
            return {"host": host, "port": port, "status": "reachable"}
    except OSError as exc:
        return {"host": host, "port": port, "status": "not reachable", "detail": str(exc)}

def get_local_network_stats() -> dict:
    counters = psutil.net_io_counters()
    return {
        "bytes_sent_total": counters.bytes_sent,
        "bytes_received_total": counters.bytes_recv,
        "packets_sent_total": counters.packets_sent,
        "packets_received_total": counters.packets_recv,
        "note": "System-wide interface counters since boot; not per-website attribution."
    }
