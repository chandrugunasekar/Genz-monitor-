"""Read-only Wazuh Manager API and Wazuh Indexer alert integration."""
import requests
from requests.auth import HTTPBasicAuth


def _base(url: str) -> str:
    return url.strip().rstrip("/")


def get_manager_token(manager_url: str, username: str, password: str, verify_tls=True) -> str:
    response = requests.get(
        f"{_base(manager_url)}/security/user/authenticate?raw=true",
        auth=HTTPBasicAuth(username, password), verify=verify_tls, timeout=12)
    response.raise_for_status()
    token = response.text.strip().strip('"')
    if not token or token.startswith("{"):
        try:
            token = response.json().get("data", {}).get("token", "")
        except ValueError:
            pass
    if not token:
        raise RuntimeError("Wazuh API did not return an authentication token.")
    return token


def get_agents(manager_url: str, token: str, verify_tls=True):
    response = requests.get(f"{_base(manager_url)}/agents?limit=100&select=id,name,ip,status",
                            headers={"Authorization": f"Bearer {token}"},
                            verify=verify_tls, timeout=15)
    response.raise_for_status()
    data = response.json().get("data", {})
    return data.get("affected_items", []), data.get("total_affected_items", 0)


def get_alerts(indexer_url: str, username: str, password: str, limit: int = 25, verify_tls=True):
    query = {"size": max(1, min(int(limit), 100)), "sort": [{"timestamp": {"order": "desc"}}],
             "query": {"match_all": {}}}
    response = requests.post(
        f"{_base(indexer_url)}/wazuh-alerts-*/_search",
        auth=HTTPBasicAuth(username, password), json=query,
        headers={"Content-Type": "application/json"}, verify=verify_tls, timeout=20)
    response.raise_for_status()
    hits = response.json().get("hits", {}).get("hits", [])
    return [hit.get("_source", {}) for hit in hits]
