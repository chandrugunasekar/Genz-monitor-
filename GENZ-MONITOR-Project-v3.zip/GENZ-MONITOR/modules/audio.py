"""Visible, operator-initiated local microphone test. Audio is never saved to disk."""
import io
import wave

import numpy as np
import sounddevice as sd


def list_input_devices():
    devices = sd.query_devices()
    return [
        {"id": idx, "name": d["name"], "channels": int(d["max_input_channels"]),
         "default_samplerate": int(d["default_samplerate"])}
        for idx, d in enumerate(devices) if int(d["max_input_channels"]) > 0
    ]


def record_test(device_id: int, seconds: int = 3, sample_rate: int = 16000):
    """Record a short sample only after an explicit UI action; return in-memory WAV bytes."""
    recording = sd.rec(int(seconds * sample_rate), samplerate=sample_rate,
                       channels=1, dtype="int16", device=device_id)
    sd.wait()
    peak = float(np.max(np.abs(recording.astype(np.int32)))) / 32768.0
    rms = float(np.sqrt(np.mean(recording.astype(np.float32) ** 2))) / 32768.0
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(recording.tobytes())
    return buffer.getvalue(), {"peak_level": round(peak, 4), "rms_level": round(rms, 4),
                               "duration_seconds": seconds, "sample_rate": sample_rate}
