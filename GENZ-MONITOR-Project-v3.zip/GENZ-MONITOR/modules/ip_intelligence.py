import ipaddress
import requests

def lookup_public_ip(ip_text: str) -> dict:
    try:
        ip_obj = ipaddress.ip_address(ip_text.strip())
    except ValueError:
        return {"error": "Enter a valid IPv4 or IPv6 address."}

    if not ip_obj.is_global:
        return {"error": "Only globally routable public IP addresses are supported by this external geolocation lookup."}

    try:
        response = requests.get(
            f"https://ipwho.is/{ip_obj}",
            timeout=8,
            headers={"User-Agent": "GENZ-MONITOR-Portfolio/1.0"}
        )
        response.raise_for_status()
        data = response.json()
        if not data.get("success", False):
            return {"error": data.get("message", "Geolocation provider could not resolve this IP.")}
        connection = data.get("connection") or {}
        timezone = data.get("timezone") or {}
        return {
            "ip": data.get("ip"),
            "type": data.get("type"),
            "country": data.get("country"),
            "region": data.get("region"),
            "city": data.get("city"),
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),
            "timezone": timezone.get("id"),
            "isp": connection.get("isp"),
            "organization": connection.get("org"),
            "asn": connection.get("asn"),
            "domain": connection.get("domain"),
            "note": "Approximate IP network location; not an exact user/device location."
        }
    except requests.RequestException as exc:
        return {"error": f"Lookup request failed: {exc}"}
