import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "monitoring.db"

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS ip_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ip TEXT, country TEXT,
            city TEXT, isp TEXT, asn TEXT, searched_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS camera_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, camera_ip TEXT,
            results_json TEXT, checked_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")

def save_ip_search(result):
    with connect() as con:
        con.execute(
            "INSERT INTO ip_history(ip,country,city,isp,asn) VALUES(?,?,?,?,?)",
            (result.get("ip"), result.get("country"), result.get("city"),
             result.get("isp"), str(result.get("asn") or ""))
        )

def get_ip_history():
    with connect() as con:
        return con.execute(
            "SELECT id,ip,country,city,isp,asn,searched_at FROM ip_history ORDER BY id DESC"
        ).fetchall()

def clear_ip_history():
    with connect() as con:
        con.execute("DELETE FROM ip_history")

def save_camera_check(result):
    with connect() as con:
        con.execute(
            "INSERT INTO camera_history(camera_ip,results_json) VALUES(?,?)",
            (result.get("camera_ip"), json.dumps(result.get("services", {})))
        )

def get_camera_history():
    with connect() as con:
        return con.execute(
            "SELECT id,camera_ip,results_json,checked_at FROM camera_history ORDER BY id DESC"
        ).fetchall()
