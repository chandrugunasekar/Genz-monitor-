import socket
from datetime import datetime
from urllib.parse import quote, urlsplit, urlunsplit

import cv2

CAMERA_PORTS = {"HTTP": 80, "HTTPS": 443, "RTSP": 554, "ONVIF commonly 8000": 8000}


def check_camera_ports(host: str) -> dict:
    services = {}
    for label, port in CAMERA_PORTS.items():
        try:
            with socket.create_connection((host, port), timeout=1.5):
                services[label] = "reachable"
        except OSError as exc:
            services[label] = f"not reachable ({exc.__class__.__name__})"
    return {"camera_ip": host, "checked_at": datetime.now().isoformat(), "services": services,
            "note": "Port reachability does not confirm camera identity or authorize video access."}


def build_rtsp_url(host: str, path: str, username: str = "", password: str = "", port: int = 554) -> str:
    """Build a URL from operator-entered camera details; never log or persist credentials."""
    path = path.strip()
    if not path.startswith("/"):
        path = "/" + path
    auth = ""
    if username:
        auth = quote(username, safe="") + ":" + quote(password, safe="") + "@"
    return f"rtsp://{auth}{host.strip()}:{int(port)}{path}"


def read_rtsp_frame(url: str, timeout_ms: int = 5000):
    """Read one frame from an authorized RTSP endpoint and release the connection."""
    params = [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, timeout_ms,
              cv2.CAP_PROP_READ_TIMEOUT_MSEC, timeout_ms]
    cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG, params)
    try:
        if not cap.isOpened():
            return None, "Could not open RTSP stream. Check camera address, path, credentials and network/firewall."
        ok, frame = cap.read()
        if not ok or frame is None:
            return None, "Stream connected but no video frame was received."
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), None
    finally:
        cap.release()
