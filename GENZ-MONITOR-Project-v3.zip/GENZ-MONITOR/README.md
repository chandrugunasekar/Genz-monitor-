# GENZ MONITOR

A defensive network-monitoring and SOC portfolio dashboard built with Python and Streamlit.

## Implemented modules
- Public IP intelligence lookup, approximate geolocation, ISP/ASN and SQLite search history.
- Authorized host ping, TCP reachability and local network counters.
- Website/domain usage summaries from authorized DNS, proxy or firewall CSV exports.
- CCTV service health checks and **authorized RTSP live preview** (refreshes approximately once per second).
- **Local microphone test**: lists input devices and records a three-second sample only after an explicit button click. Playback is in-memory; the app does not write audio files.
- **Wazuh read-only integration**: Wazuh Manager API agent inventory plus recent alert documents from Wazuh Indexer (`wazuh-alerts-*`).
- CSV exports for IP history, camera checks, website usage and Wazuh alerts.

## Requirements
- Python 3.10+
- Windows 10/11, Linux or macOS
- Network access to the camera/Wazuh services you administer
- For microphone testing, an available local input device and working PortAudio backend

## Install on Windows
Open PowerShell in the project directory:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If `py` is unavailable, use `python` instead. On Linux, `sounddevice` may require the system PortAudio package (for Debian/Ubuntu: `sudo apt install libportaudio2`).

## CCTV live preview
1. Use a camera you own or are explicitly authorized to monitor.
2. Enable RTSP in the camera's official administration interface.
3. Get the exact RTSP path from the vendor documentation or administrator. The app does not scan for stream paths or guess credentials.
4. Open **CCTV Monitoring**, enter camera host, RTSP port, exact path, and authorized credentials, then click **Start live view**.
5. Click **Stop live view** when finished.

The preview reads a frame about once per second. The RTSP URL and credentials are held in Streamlit session memory only; they are not inserted into the SQLite history or application logs by this code. Use a dedicated least-privilege camera account and a trusted network. RTSP commonly lacks transport encryption; use a protected network/VPN where appropriate.


## Laptop, USB and mobile camera studio
Open **Camera Studio** in GENZ MONITOR. Click the component's Start button and grant camera permission in the browser. The browser camera is the device opening the dashboard: a laptop webcam, a USB webcam connected to that computer, or a phone's front/rear camera when the dashboard is opened on the phone. The mobile front/rear preference is provided in the page; browser/device camera selection may also be available in the browser permission UI.

For a phone to connect to a Streamlit server on another computer over the LAN, serve the dashboard over **HTTPS**. Browsers generally block camera access from an ordinary insecure LAN HTTP address; `localhost` is treated as a secure context on the same device. Use a trusted TLS certificate/reverse proxy and restrict dashboard access. The camera component does not save video or provide hidden/background recording.

The **CCTV Monitoring** page remains separate and displays an explicitly configured, authenticated RTSP camera stream. Thus the dashboard supports laptop/USB/mobile browser cameras plus IP CCTV RTSP streams in one application.

## Microphone test
1. Open **Audio Management** and select a local input device.
2. Click **Record 3-second microphone test**.
3. Review the input level and playback, then leave the page.

No background capture, remote microphone activation, continuous recording, or audio file storage is implemented. Microphone permissions are controlled by the operating system/browser environment.

## Wazuh integration
The dashboard uses two Wazuh services:

- **Manager API** (commonly `https://<manager>:55000`) to authenticate and read the agent inventory.
- **Indexer API** (commonly `https://<indexer>:9200`) to query `wazuh-alerts-*` for recent alert documents.

Create dedicated read-only accounts/roles for the API and Indexer. Ensure the Streamlit host can reach both services. In **Security Center**, enter the URLs and credentials and click **Connect to Wazuh (read-only)**. Credentials are used for that request and are not stored in the project database. Keep TLS certificate verification enabled; install/trust your CA certificate on the host if using a private CA. Do not disable TLS verification in production.

The Wazuh Manager API account must have permission to read agents. The Indexer account must have read/search permission for `wazuh-alerts-*`. Wazuh deployments differ in role mappings and index names, so adjust the endpoint/index pattern to match your deployment if customized.

## Website analytics CSV
Required columns: `domain`, `bytes_sent`, `bytes_received`. Optional: `timestamp`, `client_ip`.

```csv
timestamp,client_ip,domain,bytes_sent,bytes_received
2026-11-12T10:00:00,192.168.1.10,example.com,1200,50000
```

Use logs exported from systems you administer. HTTPS usually prevents passive monitoring from seeing full URLs or page contents.

## Security and limitations
- Monitor only networks, hosts and cameras you own or have explicit permission to administer.
- The RTSP page accesses only the exact stream endpoint and credentials entered by the operator; it does not bypass authentication.
- A microphone recording occurs only after a visible, explicit local button action and is not saved by the app.
- Wazuh integration is read-only; it does not isolate endpoints, change rules, or modify agents.
- Store credentials in a secrets manager in production; use HTTPS for the Streamlit dashboard and restrict access to it.
- IP geolocation is approximate. MAC addresses are generally visible only on the same Layer-2 network. Local network counters are system-wide, not per-site.
- An open port, unusual country, or SIEM alert is an investigation lead—not proof of compromise.
